<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<!DOCTYPE html>
<html >
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="chrome=1">
<meta name="description" content="Clean and minimal jQuery Mobile Themes and Theme Generator">
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
 <title> Provedores Grupo Site</title>


<script type="application/javascript" src="<?php echo base_url('assets/plugins/jquery-2.1.4.min.js');?>"></script>
<script type="application/javascript" src="<?php echo base_url('assets/plugins/jquery.mobile-1.4.5/jquery.mobile-1.4.5.min.js');?>"></script>
<script type="application/javascript" src="<?php echo base_url('assets/js/login.js');?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/plugins/jquery.mobile-1.4.5/jquery.mobile-1.2.0.css');?>">
<link rel="icon" type="image/png" href="images/favicon.png">
</head>

<body class="ui-mobile-viewport ui-overlay-c">
  <div class="login">
     <div data-role="header" data-position="fixed" class="ui-header ui-bar-a ui-header-fixed slidedown ui-fixed-hidden" role="banner">
    <a href="#" data-role="button" class="ui-btn-left ui-btn ui-shadow ui-btn-corner-all ui-btn-up-a" data-corners="true" data-shadow="true" data-iconshadow="true" data-wrapperels="span" data-theme="a">
<!--        <span class="ui-btn-inner">
            <span class="ui-btn-text">Atras</span>
        </span>-->
    </a>
    <h1 class="ui-title" role="heading" aria-level="1">Grupo Site</h1>
  </div> 
        

      <div data-role="content" class="ui-content" role="main">
        <div data-role="fieldcontain" class="ui-field-contain ui-body ui-br">

          <br></br>
<?php echo form_open('/VerifyLogin');?>
          <div class="ui-input-text ui-shadow-inset ui-corner-all ui-btn-shadow ui-body-c">
              <?php
                      echo form_input(array('name' => 'username', 'value' => set_value('username'),'class' => 'ui-input-text ui-body-c tdc01', 'id' => 'td01', 'placeholder'=>'Usuario','required'=>'required')) ;
             ?>
               </div>
          <br>
           <div class="ui-input-text ui-shadow-inset ui-corner-all ui-btn-shadow ui-body-c">
              <?php
                      echo form_password(array('name' => 'password', 'value' => set_value('password'),'class' => 'ui-input-text ui-body-c tdc02' , 'id' => 'td02', 'placeholder'=>'Password','required'=>'required')) ;
             ?>
          </div>
         <?php echo form_submit(array('name' => 'acceso', 'value' => 'Aceptar' , 'id' => 'btn01' ,'class' => 'ui-btn ui-input-btn ui-shadow ui-btn-corner-all ui-btn-up-c ui-btn-inner ui-btn-text')); ?>
         <?php echo form_error('password');?>
<?php echo form_close();?>              
     </div>

</div>


</body>
  
</html>
