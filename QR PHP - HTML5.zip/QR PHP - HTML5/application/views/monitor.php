<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="chrome=1">
<meta name="description" content="Clean and minimal jQuery Mobile Themes and Theme Generator">
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
 <title> Provedores Grupo Site</title>


<script type="application/javascript" src="<?php echo base_url('assets/plugins/jquery-2.1.4.min.js');?>"></script>
<script type="application/javascript" src="<?php echo base_url('assets/plugins/jquery.mobile-1.4.5/jquery.mobile-1.4.5.min.js');?>"></script>
<script type="application/javascript" src="<?php echo base_url('assets/js/monitor.js');?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/plugins/jquery.mobile-1.4.5/jquery.mobile-1.2.0.css');?>">
<link rel="icon" type="image/png" href="images/favicon.png">
</head>
    
<body class="ui-mobile-viewport ui-overlay-c">
  <div class="Monitor">
     <div data-role="header" data-position="fixed" class="ui-header ui-bar-a ui-header-fixed slidedown ui-fixed-hidden" role="banner">
    <a href="#" data-role="button" class="ui-btn-left ui-btn ui-shadow ui-btn-corner-all ui-btn-up-a" data-corners="true" data-shadow="true" data-iconshadow="true" data-wrapperels="span" data-theme="a">

    </a>
         <STYLE type="text/css">
                H1.ui-title {text-align: center}
        </STYLE>
    <h1 class="ui-title" role="heading" aria-level="1">Grupo Site</h1>
  </div> 
      
      <div data-role="listview" data-inset="true" class="ui-listview ui-listview-inset ui-corner-all ui-shadow">
          <div class="ui-body">
                <STYLE type="text/css">
                H1.ui-status {text-align: center}
                </STYLE>
              <h1 class="ui-status"><?php echo $estado;?></h1>
                <STYLE type="text/css">
                .ui-image {display: block;margin: 0 auto;}
                </STYLE>
            <?php echo '<img class="ui-image" src="data:image/jpeg;base64,'.$foto.'">';?>
                <STYLE type="text/css">
                H1.ui-status {text-align: center}
                </STYLE>
              <h1 class="ui-status"><?php echo $nombre;?></h1>
              
            <div data-role="collapsible" data-collapsed="true" data-theme="a" class="ui-collapsible ui-collapsible-inset ui-corner-all">
                <h3 class="ui-collapsible-heading">
                    <a href="#" class="ui-collapsible-heading-toggle ui-btn ui-fullsize ui-btn-icon-left ui-btn-up-a" data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-icon="plus" data-iconpos="left" data-theme="a" data-mini="false">
                        <span class="ui-btn-inner">
                            <span class="ui-btn-text">Mas Datos<span class="ui-collapsible-heading-status"> click to collapse contents</span></span>
                            <span class="ui-icon ui-icon-shadow ui-icon-minus">&nbsp; </span>
                        </span>
                    </a>
                </h3>
                <div class="ui-collapsible-content" aria-hidden="false">

                    <p> 
                    <strong>Nombre: </strong><a><?php echo $nombre;?></a>
                        <br>
                        <strong>Dependencia: </strong><a><?php echo $dependencia;?></a>  
                        <br>
                        <strong>Puesto: </strong><a><?php echo $observaciones;?></a>  
                    </p>
            </div></div><!-- /collapsible -->
          </div>
    </div>
      
    </body>

</html>
