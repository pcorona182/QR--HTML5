<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    function index(){
        
    }

////Login General
    function login_general($username, $password) {
        //$CI = &get_instance();
        //$this->db = $CI->load->database('qr', TRUE);
        
        $this->db->select('qr_id, qr_md5plate, qr_sha1pass, qr_serv_id');
        $this->db->from('qr_acceso');
        $this->db->where('qr_sha1pass', $password);
        $this->db->where('qr_md5plate', $username);
        
        $this->db->distinct();

        $query = $this->db->get();
        
        if ($query->num_rows() > 0) {
            //return $query->result();
            return $query->row();
        } else {
            return false;
        }

    }

    function login_serv_pub($serv_id){
        $this->load->library('mongo_db', array('activate'=>'default'),'mongo_db2');
        
        $this->mongo_db2->select('serv_id, serv_name, serv_dependency, serv_observations, serv_status, serv_image');
        $this->mongo_db2->where('serv_id',$serv_id);

        $query = $this->mongo_db2->get('qr_empresa01');
          
         if(count($query) > 0){
           return $query[0];
        } else {
            return false;
        }
        
    }
    

}
