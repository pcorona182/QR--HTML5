<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class VerifyLogin extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        //$this->load->model('login', '', TRUE);
    }
    
    
    function index() {
         $this->load->model('login', '', TRUE);
         $this->load->library('form_validation');
         $this->load->helper('form');
        
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        //$this->form_validation->set_rules('password', 'Contraseña', 'trim|required|xss_clean|callback_check_database');
        $this->form_validation->set_rules('password', 'Contraseña', 'trim|required|callback_check_database');
        if ($this->form_validation->run()) {
            //Go to private area 
            $this->load->helper('url');
            $this->load->library('session');

         if ($this->session->userdata('logged_in')) {
                         $session_data = $this->session->userdata('logged_in');
                          $data = array(
                               'nombre' => $session_data['name'],
                               'dependencia' =>$session_data['dependencia'],
                               'observaciones' => $session_data['observaciones'],
                               'estado' => $session_data['status'],
                               'foto' => $session_data['foto'],
                          );
                         
                         $this->load->view('monitor',$data);
               }else{
                    $this->load->helper('url');
                    $this->load->helper('form');
                    $this->load->view('login');
               }
        } else {
            //Field validation failed.  User redirected to login page
             $this->load->helper('url');
             $this->load->helper('form');
             $this->load->view('login');

        }
    }

    function loginBranch() {
 
    }

    function check_database() {
        $username = $this->input->post('username');
        $password  = $this->input->post('password');
        $this->load->Model('Login');
        $result1 = $this->Login->login_general($username, $password);
        if ($result1 != false) {

             //$result = $this->Login->login_serv_pub('31416');
            $result2 = $this->Login->login_serv_pub($result1->qr_serv_id);
             $sess_array = array(
                'id' => $result2['serv_id'],
                'name' => $result2['serv_name'],
                'dependencia' =>$result2['serv_dependency'],
                'observaciones' => $result2['serv_observations'],
                'status' => $result2['serv_status'],
                'foto' => $result2['serv_image'],
                 //cookie
            );

            $this->session->set_userdata('logged_in', $sess_array);
            return true;
        } else {
            $this->form_validation->set_message('check_database', 'Usuario o Contraseña Invalida');
            return false;
        }
    }

}

//    function logout() {
//        $this->session->unset_userdata('logged_in');
//        session_destroy();
//        //redirect('login');
//        redirect('php echo base_url();');
//    }


