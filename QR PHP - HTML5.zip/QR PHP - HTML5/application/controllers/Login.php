<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class VerifyLogin extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('captcha');
    }

    function _remap() {
        
    }

    function index() {
        
    }

    function loginRequest() {
        
    }

    function check_database() {
        
    }

    function logout() {
        
    }

}


