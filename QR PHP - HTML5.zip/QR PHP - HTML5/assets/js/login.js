/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    
    for(var i = 0; i < hashes.length; i++)
        {
         hash = hashes[i].split('=');
         vars.push(hash[1]);
         //vars[hash[0]] = hash[1];
         }
         
     return vars;
}

jQuery(document).ready(function ($) {
    var urls = getUrlVars();
    $("#td01").val(urls[0]);
    $("#td02").val(urls[1]);

});




